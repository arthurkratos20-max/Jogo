{
  "$GMObject": "",
  "%Name": "obj_dummy",
  "eventList": [],
  "managed": true,
  "name": "obj_dummy",
  "overriddenProperties": [],
  "parent": {
    "name": "Objects",
    "path": "folders/Objects.yy"
  },
  "parentObjectId": {
    "name": "obj_enemy_parent",
    "path": "objects/obj_enemy_parent/obj_enemy_parent.yy"
  },
  "persistent": false,
  "physicsAngularDamping": 0.1,
  "physicsDensity": 0.5,
  "physicsFriction": 0.2,
  "physicsGroup": 1,
  "physicsKinematic": false,
  "physicsLinearDamping": 0.1,
  "physicsObject": false,
  "physicsRestitution": 0.1,
  "physicsSensor": false,
  "physicsShape": 1,
  "physicsShapePoints": [],
  "physicsStartAwake": true,
  "properties": [],
  "resourceType": "GMObject",
  "resourceVersion": "2.0",
  "solid": false,
  "spriteId": null,
  "spriteMaskId": null,
  "visible": true
}