{
  "$GMScript": "v1",
  "%Name": "scr_navigation_ai",
  "isCompatibility": false,
  "isDnD": false,
  "name": "scr_navigation_ai",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}