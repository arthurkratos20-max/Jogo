{
  "$GMScript": "v1",
  "%Name": "scr_weapon_manager",
  "isCompatibility": false,
  "isDnD": false,
  "name": "scr_weapon_manager",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}