{
  "$GMScript": "v1",
  "%Name": "scr_types",
  "isCompatibility": false,
  "isDnD": false,
  "name": "scr_types",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}