{
  "$GMScript": "v1",
  "%Name": "scr_movement",
  "isCompatibility": false,
  "isDnD": false,
  "name": "scr_movement",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}